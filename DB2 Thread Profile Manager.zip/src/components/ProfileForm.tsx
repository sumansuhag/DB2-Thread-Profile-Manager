import { DB2Profile } from "../types/db2Types";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

interface ProfileFormProps {
  profile: DB2Profile;
  onChange: (profile: DB2Profile) => void;
}

export function ProfileForm({ profile, onChange }: ProfileFormProps) {
  const handleChange = (field: keyof DB2Profile, value: string) => {
    onChange({ ...profile, [field]: value });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-1 h-6 bg-blue-500 rounded-full" />
        <h2 className="text-lg font-semibold text-slate-100">
          DSN_PROFILE_TABLE
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="profileId" className="text-slate-300">
            PROFILEID *
          </Label>
          <Input
            id="profileId"
            value={profile.profileId}
            onChange={(e) => handleChange("profileId", e.target.value)}
            placeholder="e.g., 1"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="location" className="text-slate-300">
            LOCATION *
          </Label>
          <Input
            id="location"
            value={profile.location}
            onChange={(e) => handleChange("location", e.target.value)}
            placeholder="e.g., ::FFFF:9.30.137.28"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="role" className="text-slate-300">
            ROLE
          </Label>
          <Input
            id="role"
            value={profile.role}
            onChange={(e) => handleChange("role", e.target.value)}
            placeholder="e.g., *"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="authid" className="text-slate-300">
            AUTHID
          </Label>
          <Input
            id="authid"
            value={profile.authid}
            onChange={(e) => handleChange("authid", e.target.value)}
            placeholder="e.g., *"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="prdid" className="text-slate-300">
            PRDID
          </Label>
          <Input
            id="prdid"
            value={profile.prdid}
            onChange={(e) => handleChange("prdid", e.target.value)}
            placeholder="e.g., *"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="collid" className="text-slate-300">
            COLLID
          </Label>
          <Input
            id="collid"
            value={profile.collid}
            onChange={(e) => handleChange("collid", e.target.value)}
            placeholder="e.g., *"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="pkgname" className="text-slate-300">
            PKGNAME
          </Label>
          <Input
            id="pkgname"
            value={profile.pkgname}
            onChange={(e) => handleChange("pkgname", e.target.value)}
            placeholder="e.g., *"
            className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
          />
        </div>
      </div>
    </div>
  );
}