import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Copy, CheckCircle, AlertCircle } from "lucide-react";
import { useState } from "react";

interface SqlOutputProps {
  profileSQL: string;
  attributesSQL: string;
  errors: string[];
}

export function SqlOutput({ profileSQL, attributesSQL, errors }: SqlOutputProps) {
  const [copiedProfile, setCopiedProfile] = useState(false);
  const [copiedAttributes, setCopiedAttributes] = useState(false);

  const copyToClipboard = async (text: string, type: "profile" | "attributes") => {
    await navigator.clipboard.writeText(text);
    if (type === "profile") {
      setCopiedProfile(true);
      setTimeout(() => setCopiedProfile(false), 2000);
    } else {
      setCopiedAttributes(true);
      setTimeout(() => setCopiedAttributes(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <div className="w-1 h-6 bg-purple-500 rounded-full" />
        <h2 className="text-lg font-semibold text-slate-100">Generated SQL</h2>
      </div>

      {errors.length > 0 && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-red-400" />
            <h3 className="font-semibold text-red-400">Validation Errors</h3>
          </div>
          <ul className="space-y-1">
            {errors.map((error, index) => (
              <li key={index} className="text-sm text-red-300 flex items-start gap-2">
                <span className="text-red-400">•</span>
                {error}
              </li>
            ))}
          </ul>
        </div>
      )}

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-100">DSN_PROFILE_TABLE</CardTitle>
              <CardDescription className="text-slate-400">
                Insert statement for profile configuration
              </CardDescription>
            </div>
            <Button
              onClick={() => copyToClipboard(profileSQL, "profile")}
              variant="outline"
              size="sm"
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              {copiedProfile ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2 text-emerald-400" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-sm">
            <code className="text-slate-300">{profileSQL}</code>
          </pre>
        </CardContent>
      </Card>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-slate-100">DSN_PROFILE_ATTRIBUTES</CardTitle>
              <CardDescription className="text-slate-400">
                Insert statement for thread monitoring attributes
              </CardDescription>
            </div>
            <Button
              onClick={() => copyToClipboard(attributesSQL, "attributes")}
              variant="outline"
              size="sm"
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              {copiedAttributes ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2 text-emerald-400" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <pre className="bg-slate-950 p-4 rounded-lg overflow-x-auto text-sm">
            <code className="text-slate-300">{attributesSQL}</code>
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}