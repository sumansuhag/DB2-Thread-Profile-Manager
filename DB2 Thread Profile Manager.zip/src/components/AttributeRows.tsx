import { DB2Attribute, KEYWORD_OPTIONS, ATTRIBUTE1_VALUE } from "../types/db2Types";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Plus, Minus, Info, AlertCircle } from "lucide-react";

interface AttributeRowsProps {
  attributes: DB2Attribute[];
  profileId: string;
  onChange: (attributes: DB2Attribute[]) => void;
}

export function AttributeRows({ attributes, profileId, onChange }: AttributeRowsProps) {
  const addAttribute = () => {
    const newAttr: DB2Attribute = {
      id: Date.now().toString(),
      profileId: profileId,
      keywords: KEYWORD_OPTIONS[0],
      attribute1: ATTRIBUTE1_VALUE,
      attribute2: "*",
      attribute3: 50,
      isAttribute3Null: false,
    };
    onChange([...attributes, newAttr]);
  };

  const removeAttribute = (id: string) => {
    onChange(attributes.filter((attr) => attr.id !== id));
  };

  const updateAttribute = (id: string, updates: Partial<DB2Attribute>) => {
    onChange(
      attributes.map((attr) =>
        attr.id === id ? { ...attr, ...updates } : attr
      )
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-1 h-6 bg-emerald-500 rounded-full" />
          <h2 className="text-lg font-semibold text-slate-100">
            DSN_PROFILE_ATTRIBUTES
          </h2>
        </div>
        <Button
          onClick={addAttribute}
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Attribute
        </Button>
      </div>

      {attributes.length === 0 ? (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 text-center">
          <p className="text-slate-400">No attributes defined. Click "Add Attribute" to begin.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {attributes.map((attr, index) => (
            <div
              key={attr.id}
              className={`bg-slate-800 border rounded-lg p-4 transition-all ${
                attr.isAttribute3Null
                  ? "border-red-500/50 ring-1 ring-red-500/20"
                  : "border-slate-700"
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-400">Row {index + 1}</span>
                  {attr.isAttribute3Null && (
                    <span className="px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded-full border border-red-500/30">
                      No Queueing
                    </span>
                  )}
                </div>
                <Button
                  onClick={() => removeAttribute(attr.id)}
                  variant="ghost"
                  size="sm"
                  className="text-slate-400 hover:text-red-400 hover:bg-red-500/10"
                >
                  <Minus className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor={`profileId-${attr.id}`} className="text-slate-300">
                    PROFILEID
                  </Label>
                  <Input
                    id={`profileId-${attr.id}`}
                    value={attr.profileId}
                    onChange={(e) => updateAttribute(attr.id, { profileId: e.target.value })}
                    className="bg-slate-900 border-slate-700 text-slate-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`keywords-${attr.id}`} className="text-slate-300">
                    KEYWORDS
                  </Label>
                  <select
                    id={`keywords-${attr.id}`}
                    value={attr.keywords}
                    onChange={(e) => updateAttribute(attr.id, { keywords: e.target.value })}
                    className="w-full h-10 px-3 rounded-md bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {KEYWORD_OPTIONS.map((keyword) => (
                      <option key={keyword} value={keyword}>
                        {keyword}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`attr1-${attr.id}`} className="text-slate-300 flex items-center gap-2">
                    ATTRIBUTE1
                    <Info className="w-3 h-3 text-slate-500" />
                  </Label>
                  <Input
                    id={`attr1-${attr.id}`}
                    value={attr.attribute1}
                    disabled
                    className="bg-slate-900/50 border-slate-700 text-slate-500 cursor-not-allowed"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`attr2-${attr.id}`} className="text-slate-300">
                    ATTRIBUTE2
                  </Label>
                  <Input
                    id={`attr2-${attr.id}`}
                    value={attr.attribute2}
                    onChange={(e) => updateAttribute(attr.id, { attribute2: e.target.value })}
                    className="bg-slate-900 border-slate-700 text-slate-100"
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={`attr3-${attr.id}`} className="text-slate-300 flex items-center gap-2">
                      ATTRIBUTE3 (Thread Queue Limit)
                      <div className="group relative">
                        <Info className="w-3 h-3 text-slate-500" />
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-2 bg-slate-950 border border-slate-700 rounded text-xs text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                          {attr.isAttribute3Null
                            ? "When NULL, connections beyond the threshold are suspended."
                            : "Max queued threads before exception."}
                        </div>
                      </div>
                    </Label>
                    <button
                      onClick={() =>
                        updateAttribute(attr.id, {
                          isAttribute3Null: !attr.isAttribute3Null,
                        })
                      }
                      className={`px-3 py-1 text-xs rounded-full transition-all ${
                        attr.isAttribute3Null
                          ? "bg-red-500/20 text-red-400 border border-red-500/30"
                          : "bg-slate-700 text-slate-300 border border-slate-600"
                      }`}
                    >
                      {attr.isAttribute3Null ? "NULL (No Queueing)" : "Set Value"}
                    </button>
                  </div>

                  {attr.isAttribute3Null ? (
                    <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-md">
                      <AlertCircle className="w-4 h-4 text-red-400" />
                      <span className="text-sm text-red-400">NULL - Connections will be suspended</span>
                    </div>
                  ) : (
                    <Input
                      id={`attr3-${attr.id}`}
                      type="number"
                      min={0}
                      max={9999}
                      value={attr.attribute3}
                      onChange={(e) =>
                        updateAttribute(attr.id, {
                          attribute3: parseInt(e.target.value) || 0,
                        })
                      }
                      className="bg-slate-900 border-slate-700 text-slate-100"
                    />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}