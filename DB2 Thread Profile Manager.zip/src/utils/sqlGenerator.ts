import { DB2Config, DB2Profile, DB2Attribute } from "../types/db2Types";

export function validateProfile(config: DB2Config): {
  isValid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (!config.profile.profileId.trim()) {
    errors.push("PROFILEID is required");
  }

  if (!config.profile.location.trim()) {
    errors.push("LOCATION is required");
  }

  config.attributes.forEach((attr, index) => {
    if (!attr.profileId.trim()) {
      errors.push(`Attribute row ${index + 1}: PROFILEID is required`);
    }
    if (!attr.keywords.trim()) {
      errors.push(`Attribute row ${index + 1}: KEYWORDS is required`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
  };
}

export function generateProfileSQL(profile: DB2Profile): string {
  const parts = [
    `INSERT INTO DSN_PROFILE_TABLE`,
    `  (PROFILEID, LOCATION, ROLE, AUTHID, PRDID, COLLID, PKGNAME)`,
    `VALUES`,
    `  ('${profile.profileId}', '${profile.location}', '${profile.role}', '${profile.authid}', '${profile.prdid}', '${profile.collid}', '${profile.pkgname}');`,
  ];
  return parts.join("\n");
}

export function generateAttributesSQL(attributes: DB2Attribute[]): string {
  if (attributes.length === 0) return "-- No attributes defined";

  const statements = attributes.map((attr) => {
    const attr3Value = attr.isAttribute3Null ? "NULL" : attr.attribute3;
    return `  ('${attr.profileId}', '${attr.keywords}', '${attr.attribute1}', '${attr.attribute2}', ${attr3Value})`;
  });

  const parts = [
    `INSERT INTO DSN_PROFILE_ATTRIBUTES`,
    `  (PROFILEID, KEYWORDS, ATTRIBUTE1, ATTRIBUTE2, ATTRIBUTE3)`,
    `VALUES`,
    statements.join(",\n"),
    ";",
  ];
  return parts.join("\n");
}

export function generateFullSQL(config: DB2Config): {
  profileSQL: string;
  attributesSQL: string;
  validation: ReturnType<typeof validateProfile>;
} {
  const validation = validateProfile(config);
  const profileSQL = generateProfileSQL(config.profile);
  const attributesSQL = generateAttributesSQL(config.attributes);

  return { profileSQL, attributesSQL, validation };
}