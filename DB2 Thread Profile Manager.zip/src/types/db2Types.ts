export interface DB2Profile {
  profileId: string;
  location: string;
  role: string;
  authid: string;
  prdid: string;
  collid: string;
  pkgname: string;
}

export interface DB2Attribute {
  id: string;
  profileId: string;
  keywords: string;
  attribute1: string;
  attribute2: string;
  attribute3: number | null;
  isAttribute3Null: boolean;
}

export interface DB2Config {
  profile: DB2Profile;
  attributes: DB2Attribute[];
}

export const KEYWORD_OPTIONS = [
  "MONITOR THREADS",
  "MONITOR ALL THREADS",
  "MONITOR ALL CONNECTIONS",
];

export const ATTRIBUTE1_VALUE = "EXCEPTION";