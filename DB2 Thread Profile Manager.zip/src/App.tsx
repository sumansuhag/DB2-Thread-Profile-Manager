import { useState, useEffect } from "react";
import { DB2Config, DB2Attribute } from "./types/db2Types";
import { ProfileForm } from "./components/ProfileForm";
import { AttributeRows } from "./components/AttributeRows";
import { SqlOutput } from "./components/SqlOutput";
import { generateFullSQL } from "./utils/sqlGenerator";
import { Database, Settings } from "lucide-react";

function App() {
  const [config, setConfig] = useState<DB2Config>({
    profile: {
      profileId: "1",
      location: "::FFFF:9.30.137.28",
      role: "*",
      authid: "*",
      prdid: "*",
      collid: "*",
      pkgname: "*",
    },
    attributes: [
      {
        id: "1",
        profileId: "1",
        keywords: "MONITOR THREADS",
        attribute1: "EXCEPTION",
        attribute2: "*",
        attribute3: 50,
        isAttribute3Null: false,
      },
    ],
  });

  const [sqlOutput, setSqlOutput] = useState(() => generateFullSQL(config));

  useEffect(() => {
    setSqlOutput(generateFullSQL(config));
  }, [config]);

  const handleProfileChange = (profile: typeof config.profile) => {
    setConfig((prev) => ({
      ...prev,
      profile,
      attributes: prev.attributes.map((attr) => ({
        ...attr,
        profileId: profile.profileId,
      })),
    }));
  };

  const handleAttributesChange = (attributes: DB2Attribute[]) => {
    setConfig((prev) => ({
      ...prev,
      attributes,
    }));
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-100">
                DB2 Thread Profile Manager
              </h1>
              <p className="text-sm text-slate-400">
                Visual configuration for DSN_PROFILE_TABLE and DSN_PROFILE_ATTRIBUTES
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
              <ProfileForm
                profile={config.profile}
                onChange={handleProfileChange}
              />
            </div>

            <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
              <AttributeRows
                attributes={config.attributes}
                profileId={config.profile.profileId}
                onChange={handleAttributesChange}
              />
            </div>
          </div>

          <div className="lg:sticky lg:top-24 h-fit">
            <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
              <SqlOutput
                profileSQL={sqlOutput.profileSQL}
                attributesSQL={sqlOutput.attributesSQL}
                errors={sqlOutput.validation.errors}
              />
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-slate-800 mt-16 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-slate-500">
          <p>DB2 Thread Profile Manager — Generate IBM-compliant SQL without typing</p>
        </div>
      </footer>
    </div>
  );
}

export default App;